
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Mail </title>
  </head>
  <body>
  <section class='section' style='padding:0 !important; margin:0 !important; display:block !important; min-width:100% !important; width:100% !important; background:#f4f4f4; -webkit-text-size-adjust:none;'>
			<table width='100%' border='0' cellspacing='0' cellpadding='0' bgcolor='#f4f4f4'>
				<tr>
					<td align='center' valign='top'>
						<table width='650' border='0' cellspacing='0' cellpadding='0' class='mobile-shell'>
							<tr>
								<td class='td container' style='width:650px; min-width:650px; font-size:0pt; line-height:0pt; margin:0; font-weight:normal; padding:55px 0px;'>

									<table width='100%' border='0' cellspacing='0' cellpadding='0'>
										<tr>
											<td style='padding-bottom: 20px;'>
												<table width='100%' border='0' cellspacing='0' cellpadding='0'>
													<tr>
														<td class='p30-15' style='padding: 25px 30px 25px 30px;' bgcolor='#000014'>
															<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																<tr>
																	<th class='column-top' width='145' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;'>
																		<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																			<tr>
																				<td class='img m-center' style='font-size:0pt; line-height:0pt; text-align:left;'><img src='https://auxilliarytradex.com/images/emailimages/logo.png' width='167' height='31' border='0' alt='' /></td>
																			</tr>
																		</table>
																	</th>
																	<th class='column-empty' width='1' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;'></th>
																	<th class='column' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal;'>
																		<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																			<tr>
																				<td class='text-header' style='color:#999999; font-family:Noto Sans, Arial,sans-serif; font-size:12px; line-height:16px; text-align:right; text-transform:uppercase;'><a href='https://auxilliarytradex.com/' target='_blank' class='link2' style='color:#999999; text-decoration:none;'><span class='link2' style='color:#999999; text-decoration:none;'>Open in your browser</span></a></td>
																			</tr>
																		</table>
																	</th>
																</tr>
															</table>
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>

									<table width='100%' border='0' cellspacing='0' cellpadding='0'>
										<tr>
											<td style='padding-bottom: 20px;'>
												<table width='100%' border='0' cellspacing='0' cellpadding='0'>
													<tr>
														<td background='https://auxilliarytradex.com/images/emailimages/image1.png' bgcolor='#114490' valign='top' height='366' class='bg' style='background-size:cover !important; -webkit-background-size:cover !important; background-repeat:none;'>

															<div>
																<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																	<tr>
																		<td class='content-spacing' width='30' height='366' style='font-size:0pt; line-height:0pt; text-align:left;'></td>
																		<td style='padding: 30px 0px;'>
																			<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																				<tr>
																					<td class='h1 center pb25' style='color:#ffffff; font-family:Noto Sans, Arial,sans-serif; font-size:40px; line-height:46px; text-align:center; padding-bottom:25px;'>Exquisite Option</td>
																				</tr>
																				<tr>
																					<td class='text-center' style='color:#ffffff; font-family:Noto Sans, Arial,sans-serif; font-size:16px; line-height:30px; text-align:center;'>Wealth and finance </td>
																				</tr>
																			</table>
																		</td>
																		<td class='content-spacing' width='30' style='font-size:0pt; line-height:0pt; text-align:left;'></td>
																	</tr>
																</table>
															</div>


														</td>
													</tr>
													<tr>
														<td class='mp15' style='padding: 20px 30px;' bgcolor='#000014' align='center'>
															<table border='0' cellspacing='0' cellpadding='0'>
																<tr>
																	<th class='column' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal;'>
																		<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																			<tr>
																				<td class='h5 white' style='font-family:Noto Sans, Arial,sans-serif; font-size:16px; line-height:22px; text-align:left; font-weight:bold; color:#ffffff;'>1) SIGN UP</td>
																			</tr>
																		</table>
																	</th>
																	<th class='column' width='50' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal;'></th>
																	<th class='column' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal;'>
																		<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																			<tr>
																				<td class='h5 white' style='font-family:Noto Sans, Arial,sans-serif; font-size:16px; line-height:22px; text-align:left; font-weight:bold; color:#ffffff;'>2) FUND YOUR ACCOUNT</td>
																			</tr>
																		</table>
																	</th>
																	<th class='column' width='50' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal;'></th>
																	<th class='column' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal;'>
																		<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																			<tr>
																				<td class='h5 white' style='font-family:Noto Sans, Arial,sans-serif; font-size:16px; line-height:22px; text-align:left; font-weight:bold; color:#ffffff;'>3) START EARNING</td>
																			</tr>
																		</table>
																	</th>
																</tr>
															</table>
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>

									<table width='100%' border='0' cellspacing='0' cellpadding='0'>
										<tr>
											<td style='padding-bottom: 20px;'>
												<table width='100%' border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff'>
													<tr>
														<td class='p30-15' style='padding: 50px 30px;'>
															<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																<tr>
																	<td class='h3 pb20' style='color:#114490; font-family:Noto Sans, Arial,sans-serif; font-size:24px; line-height:32px; text-align:left; padding-bottom:20px;'>{!! $emaildata['email_header'] !!}</td>
																</tr>
																<tr>
																	<td class='text pb20' style='color:#777777; font-family:Noto Sans, Arial,sans-serif; font-size:14px; line-height:26px; text-align:left; padding-bottom:20px;'>Sir <br>{!! $emaildata['email_body'] !!}</td>
																</tr>

																<tr>
																	<td align='left'>
																		<table border='0' cellspacing='0' cellpadding='0'>
																			<tr>
																				<td class='text-button' style='background:#114490; color:#ffffff; font-family:Noto Sans, Arial,sans-serif; font-size:14px; line-height:18px; padding:12px 20px; text-align:center; border-radius:6px;'><a href='https://auxilliarytradex.com/about' target='_blank' class='link-white' style='color:#ffffff; text-decoration:none;'><span class='link-white' style='color:#ffffff; text-decoration:none;'>FIND OUT MORE ABOUT US</span></a></td>
																			</tr>
																		</table>
																	</td>
																</tr>

															</table>
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>

									<table width='100%' border='0' cellspacing='0' cellpadding='0'>
										<tr>
											<td style='padding-bottom: 20px;'>
												<table width='100%' border='0' cellspacing='0' cellpadding='0'>
													<tr>
														<th class='column-top' width='275' bgcolor='#ffffff' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;'>
															<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																<tr>
																	<td class='fluid-img p20' style='font-size:0pt; line-height:0pt; text-align:left; padding:20px;'><img src='https://auxilliarytradex.com/images/emailimages/image3.png' width='275' height='207' border='0' alt='' /></td>
																</tr>
															</table>
														</th>
														<th class='column-empty2' width='20' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;'></th>
														<th class='column-top' width='275' bgcolor='#ffffff' style='font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;'>
															<table width='100%' border='0' cellspacing='0' cellpadding='0'>
																<tr>
																	<td class='fluid-img p20' style='font-size:0pt; line-height:0pt; text-align:left; padding:20px;'><img src='https://auxilliarytradex.com/images/emailimages/image4.png' width='275' height='207' border='0' alt='' /></td>
																</tr>
															</table>
														</th>
													</tr>
												</table>
											</td>
										</tr>
									</table>
									<table width='100%' border='0' cellspacing='0' cellpadding='0'>
										<tr>
											<td class='p30-15' style='padding: 50px 30px;' bgcolor='#ffffff'>
												<table width='100%' border='0' cellspacing='0' cellpadding='0'>
													<tr>
														<td align='center' style='padding-bottom: 30px;'>

														</td>
													</tr>
													<tr>
														<td class='text-footer1 pb10' style='color:#999999; font-family:Noto Sans, Arial,sans-serif; font-size:16px; line-height:20px; text-align:center; padding-bottom:10px;'>Auxilliary Tradex - Recommended by Google</td>
													</tr>
													<tr>
														<td class='text-footer2 pb30' style='color:#999999; font-family:Noto Sans, Arial,sans-serif; font-size:12px; line-height:26px; text-align:center; padding-bottom:30px;'>United Kingdom</td>
													</tr>
													<tr>
														<td class='text-footer3' style='color:#c0c0c0; font-family:Noto Sans, Arial,sans-serif; font-size:12px; line-height:18px; text-align:center;'><a href='#' target='_blank' class='link3-u' style='color:#c0c0c0; text-decoration:underline;'><span class='link3-u' style='color:#c0c0c0; text-decoration:underline;'>Unsubscribe</span></a> from this mailing list.</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>

								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</section>

  </body>
</html>
